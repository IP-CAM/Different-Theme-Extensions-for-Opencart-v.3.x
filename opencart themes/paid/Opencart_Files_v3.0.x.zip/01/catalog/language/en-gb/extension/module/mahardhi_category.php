<?php
// Heading
$_['heading_title']      = 'Categories';

// Text
$_['text_blog']          = 'Blogs';
$_['text_all']           = 'Show All';
$_['text_home']          = 'Home';
