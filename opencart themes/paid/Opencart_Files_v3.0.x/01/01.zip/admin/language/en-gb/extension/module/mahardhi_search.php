<?php
// Heading
$_['heading_title']    = 'Mahardhi Search';

$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified mahardhi module!';
$_['text_edit']        = 'Edit mahardhi search Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_autocomplete'] = 'Autocomplete';
$_['entry_category']   = 'Categoty';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify mahardhi search module!';
