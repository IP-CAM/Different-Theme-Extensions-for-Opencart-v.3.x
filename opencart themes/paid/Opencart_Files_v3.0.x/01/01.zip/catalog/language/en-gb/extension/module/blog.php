<?php
// Text
$_['text_more']  		= 'Read more';
$_['text_date_added'] 	= 'Added:';
$_['text_viewed'] 		= '%s views';
$_['text_comment']		= 'Comments';

// Buttons
$_['button_list']     	= 'View all';

?>
