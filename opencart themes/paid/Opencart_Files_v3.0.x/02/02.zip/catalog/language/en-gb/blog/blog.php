<?php
// Text
$_['text_refine'] 		= 'Select a sub-category';
$_['heading_title']     = 'Blogs';
$_['text_attributes'] 	= 'Custom fields';
$_['text_error'] 		= 'Category is not found !';
$_['text_empty'] 		= 'In this category there are no materials.';
$_['text_more']			= 'Read More';
$_['hedding_comment'] 	= 'Comments';
$_['text_views'] 		= 'Views';
$_['text_blog']			= 'Blog';
$_['text_comment']		= 'Comments';
$_['text_date']			= 'Posted:';
$_['text_authore']		= 'Authore:';