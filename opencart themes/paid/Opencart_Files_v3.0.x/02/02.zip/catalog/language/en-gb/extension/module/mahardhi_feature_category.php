<?php
// Heading
$_['heading_title'] = 'The Collection';

// Text
$_['text_tax']      = 'Ex Tax:';