<?php
// Heading
$_['heading_title']    = 'Top Products';

$_['tab_latest']       = 'Latest';
$_['tab_bestseller']   = 'Bestseller';
$_['tab_featured']     = 'Featured';
$_['tab_special']      = 'Special';

// Text
$_['button_wishlist']  = 'Add to wishlist';
$_['button_compare']   = 'Compare';
$_['text_tax']         = 'Without tax:';
?>
