<?php
// Text
$_['text_home']          = 'Home';
$_['text_wishlist']      = 'WishList (%s)';
$_['text_shopping_cart'] = 'Shopping Cart';
$_['text_category']      = 'Categories';
$_['text_account']       = 'Account';
$_['text_register']      = 'Register';
$_['text_login']         = 'Login';
$_['text_order']         = 'Order History';
$_['text_transaction']   = 'Transactions';
$_['text_download']      = 'Downloads';
$_['text_logout']        = 'Logout';
$_['text_checkout']      = 'Checkout';
$_['text_search']        = 'Search';
$_['text_all']           = 'Show All';
$_['text_blog']          = 'Blogs';
$_['text_menu']      	 = 'Menu';
$_['text_allcategory']   = 'Categories';
$_['text_contacts'] 	 = 'Contact';
$_['text_manufacturers'] = 'Brands';
$_['text_telephone']     = 'customer support';
$_['text_delivery']      = "World's Fastest online Shopping Deastination";
